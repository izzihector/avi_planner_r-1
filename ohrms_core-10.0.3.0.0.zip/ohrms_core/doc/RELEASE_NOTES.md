## Module <ohrms_core>

#### 09.04.2018
#### Version 10.0.3.0.0
##### ADD
- Added additional fields in settings.

#### 31.03.2018
#### Version 10.0.2.0.0
##### CHG
- index added and depends issue fixed.

#### 30.03.2018
#### Version 10.0.1.0.0
##### ADD
- Initial commit for OpenHRMS Project